package com.example.newproduct;

import io.flutter.embedding.android.FlutterActivity;

public class MainActivity extends FlutterActivity {
}
