class AppUrl {
  static const url = "http://10.0.2.2:8080/lab_test/";
}
